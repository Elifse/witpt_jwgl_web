package com.example.witpt_jwgl_web.test;

import com.example.witpt_jwgl_web.dao.GradeDAO;
import com.example.witpt_jwgl_web.dto.StudentGrade;

import java.util.List;

/**
 * @author Elifse
 * @Description
 * @Create 2022/4/16
 **/
public class test {
    public static void main(String[] args) {
        GradeDAO gradeDAO = new GradeDAO();
        List<StudentGrade> sg = gradeDAO.selectGradeByStudentId("6930050104");
        for (int i = 0; i < sg.size(); i++) {
            StudentGrade studentGrades = sg.get(i);
            System.out.println(studentGrades.getStudentId());
            System.out.println(studentGrades.getCourseName());
            System.out.println(studentGrades.getGrade());

        }

    }
}
