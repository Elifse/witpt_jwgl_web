package com.example.witpt_jwgl_web.servlets;

import com.example.witpt_jwgl_web.dao.ManagerDAO;
import com.example.witpt_jwgl_web.dao.StudentDAO;
import com.example.witpt_jwgl_web.dao.TeacherDAO;
import com.example.witpt_jwgl_web.dto.ManagerDTO;
import com.example.witpt_jwgl_web.dto.StudentDTO;
import com.example.witpt_jwgl_web.dto.TeacherDTO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author Elifse
 * @Description 登录Servlet
 * @Create 2022/4/15
 **/
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    // ovdoget
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    }

    // ovdopost
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 接受登录页面提交的数据：用户名、密码、身份
        String s1 = req.getParameter("account");
        String s2 = req.getParameter("pwd");
        String s3 = req.getParameter("role");
        // 判断身份，跳转到不同的页面
        if (s3.equals("student")) {
            // 跳转到学生页面
            StudentDAO sdao = new StudentDAO();
            StudentDTO sdto = sdao.selectStudentByIdAndPwd(s1, s2);
            if (sdto == null) {
                // 登录失败
                req.getRequestDispatcher("index.jsp").forward(req, resp);
            }else{
                // 登录成功
                req.getSession().setAttribute("student", sdto);
                req.getRequestDispatcher("index-student.jsp").forward(req, resp);
            }

        }
        if (s3.equals("teacher")) {
            // 跳转到教师页面
            TeacherDAO tdao = new TeacherDAO();
            TeacherDTO tdto = tdao.selectTeacherByIdAndPwd(s1,s2);
            if (tdto == null) {
                // 登录失败
                req.getRequestDispatcher("index.jsp").forward(req, resp);
            }else {
                // 登录成功
                req.getSession().setAttribute("teacher", tdto);
                req.getRequestDispatcher("index-teacher.jsp").forward(req, resp);
            }
        }
        if (s3.equals("manager")) {
            // 跳转到管理员页面
            ManagerDAO mdao = new ManagerDAO();
            ManagerDTO mdto = mdao.selectManagerByIdAndPwd(s1,s2);
            if (mdto == null) {
                // 登录失败
                req.getRequestDispatcher("index.jsp").forward(req, resp);
            }else {
                // 登录成功
                req.getSession().setAttribute("manager", mdto);
                req.getRequestDispatcher("index-manager.jsp").forward(req, resp);
            }
        }
    }
}
