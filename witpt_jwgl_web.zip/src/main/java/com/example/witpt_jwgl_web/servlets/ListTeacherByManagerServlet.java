package com.example.witpt_jwgl_web.servlets;

import com.example.witpt_jwgl_web.dao.TeacherDAO;
import com.example.witpt_jwgl_web.dto.TeacherDTO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * @author Elifse
 * @Description
 * @Create 2022/4/16
 **/

@WebServlet("/ListTeacherByManagerServlet")
public class ListTeacherByManagerServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        TeacherDAO teacherDAO = new TeacherDAO();
        List<TeacherDTO> list = teacherDAO.selectAllTeachers();
        req.setAttribute("list",list);
        req.getRequestDispatcher("manager-teacher-list.jsp").forward(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    }
}
