package com.example.witpt_jwgl_web.servlets;

import com.example.witpt_jwgl_web.dao.GradeDAO;
import com.example.witpt_jwgl_web.dto.StudentDTO;
import com.example.witpt_jwgl_web.dto.StudentGrade;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * @author Elifse
 * @Description
 * @Create 2022/4/16
 **/
@WebServlet("/ListGradeByStudentServlet")
public class ListGradeByStudentServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //1. 获取学号
        StudentDTO student = (StudentDTO) req.getSession().getAttribute("student");
        String sid = student.getStudentNum();
        //2. 调用GradeDAO的根据学号查询成绩的方法
        GradeDAO gdao = new GradeDAO();
        List<StudentGrade> list = gdao.selectGradeByStudentId(sid);
        //3. 将查询到的成绩信息传递给页面
        req.setAttribute("list",list);
        req.getRequestDispatcher("student-grade-list.jsp").forward(req,resp);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    }
}
