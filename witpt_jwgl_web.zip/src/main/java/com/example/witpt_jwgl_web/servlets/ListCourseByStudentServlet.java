package com.example.witpt_jwgl_web.servlets;

import com.example.witpt_jwgl_web.dao.CourseDAO;
import com.example.witpt_jwgl_web.dto.CourseDTO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * @author Elifse
 * @Description
 * @Create 2022/4/16
 **/
@WebServlet("/ListCourseByStudentServlet")
public class ListCourseByStudentServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        CourseDAO cdao = new CourseDAO();
        List<CourseDTO> list = cdao.selectAllCourse();
        //3. 将课程信息传递给页面
        req.setAttribute("list", list);
        //4. 在teacher-course-list.jsp显示课程信息
        req.getRequestDispatcher("choose_course.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    }
}
