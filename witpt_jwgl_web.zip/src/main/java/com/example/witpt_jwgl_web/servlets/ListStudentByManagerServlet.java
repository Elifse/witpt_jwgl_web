package com.example.witpt_jwgl_web.servlets;

import com.example.witpt_jwgl_web.dao.StudentDAO;
import com.example.witpt_jwgl_web.dto.ManagerDTO;
import com.example.witpt_jwgl_web.dto.StudentDTO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * @author Elifse
 * @Description
 * @Create 2022/4/16
 **/

@WebServlet("/ListStudentByManagerServlet")
public class ListStudentByManagerServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        StudentDAO studentDAO = new StudentDAO();
        List<StudentDTO> list = studentDAO.selectAllStudent();
        req.setAttribute("list",list);
        req.getRequestDispatcher("manager-student-list.jsp").forward(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    }
}
