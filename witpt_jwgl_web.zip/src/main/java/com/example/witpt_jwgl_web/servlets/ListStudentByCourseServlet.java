package com.example.witpt_jwgl_web.servlets;

import com.example.witpt_jwgl_web.dao.StudentDAO;
import com.example.witpt_jwgl_web.dto.StudentDTO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * @author Elifse
 * @Description
 * @Create 2022/4/16
 **/
@WebServlet("/ListStudentByCourseServlet")
public class ListStudentByCourseServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //1. 接收课程的ID
        String cid = req.getParameter("cid");
        //2.查询课程的学生
        StudentDAO sdao = new StudentDAO();
        List<StudentDTO> list = sdao.selectStudentByCid(cid);
        //3. 将学生信息传递到grade-add.jsp
        req.setAttribute("list",list);
        req.getRequestDispatcher("grade-add.jsp").forward(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    }
}
