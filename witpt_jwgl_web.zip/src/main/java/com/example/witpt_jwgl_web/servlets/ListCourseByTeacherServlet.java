package com.example.witpt_jwgl_web.servlets;

import com.example.witpt_jwgl_web.dao.CourseDAO;
import com.example.witpt_jwgl_web.dto.CourseDTO;
import com.example.witpt_jwgl_web.dto.TeacherDTO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * @author Elifse
 * @Description 教师Servlet
 * @Create 2022/4/16
 **/
@WebServlet("/ListCourseByTeacherServlet")
public class ListCourseByTeacherServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //1. 获取老师的ID
        TeacherDTO teacher = (TeacherDTO) req.getSession().getAttribute("teacher");
        String tid = teacher.getTeacherId();
        //2. 调用CourseDAO根据tid查询课程
        CourseDAO cdao = new CourseDAO();
        List<CourseDTO> list = cdao.selectCourseByTid(tid);
        //3. 将课程信息传递给页面
        req.setAttribute("list", list);
        //4. 在teacher-course-list.jsp显示课程信息
        req.getRequestDispatcher("teacher-course-list.jsp").forward(req, resp);

    }


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    }
}
