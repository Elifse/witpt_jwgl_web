package com.example.witpt_jwgl_web.dto;

public class StudentDTO {
    //create table tb_students(
    //      stu_num char(10) primary key,
    //	    login_pwd varchar(20) not null,
    //	    stu_name varchar(20) not null,
    //	    stu_gender char(2) not null,
    //	    stu_age int,
    //      stu_addr varchar(100),
    //      stu_img varchar(50),
    //	    stu_desc varchar(200)
    //);
    private String StudentNum;
    private String LoginPwd;
    private String StudentName;
    private String StudentGender;
    private int StudentAge;
    private String StudentAddr;
    private String StudentImg;
    private String StudentDesc;

    public String getStudentNum() {
        return StudentNum;
    }

    public void setStudentNum(String studentNum) {
        StudentNum = studentNum;
    }

    public String getLoginPwd() {
        return LoginPwd;
    }

    public void setLoginPwd(String loginPwd) {
        LoginPwd = loginPwd;
    }

    public String getStudentName() {
        return StudentName;
    }

    public void setStudentName(String studentName) {
        StudentName = studentName;
    }

    public String getStudentGender() {
        return StudentGender;
    }

    public void setStudentGender(String studentGender) {
        StudentGender = studentGender;
    }

    public int getStudentAge() {
        return StudentAge;
    }

    public void setStudentAge(int studentAge) {
        StudentAge = studentAge;
    }

    public String getStudentAddr() {
        return StudentAddr;
    }

    public void setStudentAddr(String studentAddr) {
        StudentAddr = studentAddr;
    }

    public String getStudentImg() {
        return StudentImg;
    }

    public void setStudentImg(String studentImg) {
        StudentImg = studentImg;
    }

    public String getStudentDesc() {
        return StudentDesc;
    }

    public void setStudentDesc(String studentDesc) {
        StudentDesc = studentDesc;
    }

    public StudentDTO() {
    }

    public StudentDTO(String studentNum, String loginPwd, String studentName, String studentGender, int studentAge, String studentAddr, String studentImg, String studentDesc) {
        this.StudentNum    = studentNum;
        this.LoginPwd      = loginPwd;
        this.StudentName   = studentName;
        this.StudentGender = studentGender;
        this.StudentAge    = studentAge;
        this.StudentAddr   = studentAddr;
        this.StudentImg    = studentImg;
        this.StudentDesc   = studentDesc;
    }
}
