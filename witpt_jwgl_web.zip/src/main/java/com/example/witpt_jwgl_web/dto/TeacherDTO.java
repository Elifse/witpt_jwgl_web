package com.example.witpt_jwgl_web.dto;

/**
 * @author Elifse
 * @Description 对教师信息进行封装
 */

public class TeacherDTO {
    //create table tb_teachers(
    //	  id char(8) primary key,
    //	  login_pwd varchar(20) not null,
    //	  name varchar(20) not null,
    //	  gender char(2) not null,
    //	  birthday char(10) not null,
    //	  id_card char(18) not null unique,
    //	  tel_num char(11) not null unique
    //);
    private String TeacherId;
    private String LoginPwd;
    private String TeacherName;
    private String TeacherGender;
    private String TeacherBirthday;
    private String TeacherIdCard;
    private String TeacherTelNum;

    public String getTeacherId() {
        return TeacherId;
    }

    public void setTeacherId(String teacherId) {
        TeacherId = teacherId;
    }

    public String getLoginPwd() {
        return LoginPwd;
    }

    public void setLoginPwd(String loginPwd) {
        LoginPwd = loginPwd;
    }

    public String getTeacherName() {
        return TeacherName;
    }

    public void setTeacherName(String teacherName) {
        TeacherName = teacherName;
    }

    public String getTeacherGender() {
        return TeacherGender;
    }

    public void setTeacherGender(String teacherGender) {
        TeacherGender = teacherGender;
    }

    public String getTeacherBirthday() {
        return TeacherBirthday;
    }

    public void setTeacherBirthday(String teacherBirthday) {
        TeacherBirthday = teacherBirthday;
    }

    public String getTeacherIdCard() {
        return TeacherIdCard;
    }

    public void setTeacherIdCard(String teacherIdCard) {
        TeacherIdCard = teacherIdCard;
    }

    public String getTeacherTelNum() {
        return TeacherTelNum;
    }

    public void setTeacherTelNum(String teacherTelNum) {
        TeacherTelNum = teacherTelNum;
    }

    public TeacherDTO() {
    }

    public TeacherDTO(String teacherId, String loginPwd, String teacherName, String teacherGender, String teacherBirthday, String teacherIdCard, String teacherTelNum) {
        this.TeacherId       = teacherId;
        this.LoginPwd        = loginPwd;
        this.TeacherName     = teacherName;
        this.TeacherGender   = teacherGender;
        this.TeacherBirthday = teacherBirthday;
        this.TeacherIdCard   = teacherIdCard;
        this.TeacherTelNum   = teacherTelNum;
    }
}
