package com.example.witpt_jwgl_web.dto;

/**
 * @author Elifse
 * @Description 学生成绩容器
 * @Create 2022/4/16
 **/
public class StudentGrade {
    private String studentId;
    private String studentName;
    private String courseId;
    private String courseName;
    private String courseDescription;
    private int grade;

    public StudentGrade() {
    }

    public StudentGrade(String studentId, String studentName, String courseId, String courseName, String courseDescription, int grade) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.courseId = courseId;
        this.courseName = courseName;
        this.courseDescription = courseDescription;
        this.grade = grade;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseDescription() {
        return courseDescription;
    }

    public void setCourseDescription(String courseDescription) {
        this.courseDescription = courseDescription;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }
}
