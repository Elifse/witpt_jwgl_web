package com.example.witpt_jwgl_web.dto;

/**
 * @author Elifse
 * @Description 用来封装课程信息的DTO
 */
public class CourseDTO {
    //create table tb_courses(
    //	  course_id char(5) primary key,
    //	  course_name VARCHAR(50) not null,
    //	  course_score DECIMAL(3,1) not null,
    //	  course_time int not null,
    //	  course_desc varchar(200)
    //);
    private String CourseId;
    private String CourseName;
    private double CourseScore;
    private int CourseTime;
    private String CourseDesc;
    private String teacherId;

    public String getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(String teacherId) {
        this.teacherId = teacherId;
    }
// 构造方法 Getter and Setter

    public String getCourseId() {
        return CourseId;
    }

    public void setCourseId(String courseId) {
        CourseId = courseId;
    }

    public String getCourseName() {
        return CourseName;
    }

    public void setCourseName(String courseName) {
        CourseName = courseName;
    }

    public double getCourseScore() {
        return CourseScore;
    }

    public void setCourseScore(double courseScore) {
        CourseScore = courseScore;
    }

    public int getCourseTime() {
        return CourseTime;
    }

    public void setCourseTime(int courseTime) {
        CourseTime = courseTime;
    }

    public String getCourseDesc() {
        return CourseDesc;
    }

    public void setCourseDesc(String courseDesc) {
        CourseDesc = courseDesc;
    }


    //无参构造器

    public CourseDTO() {
    }


    //全参构造器

    public CourseDTO(String courseId, String courseName, double courseScore, int courseTime, String courseDesc, String teacherId) {
        this.CourseId = courseId;
        this.CourseName = courseName;
        this.CourseScore = courseScore;
        this.CourseTime = courseTime;
        this.CourseDesc = courseDesc;
        this.teacherId = teacherId;
    }

    public CourseDTO(String courseId, String courseName, double courseScore, int courseTime, String courseDesc) {
        CourseId = courseId;
        CourseName = courseName;
        CourseScore = courseScore;
        CourseTime = courseTime;
        CourseDesc = courseDesc;
    }
}
