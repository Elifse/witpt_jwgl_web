package com.example.witpt_jwgl_web.dto;

/**
 * @author Elifse
 * @Description 用来封装成绩的数据传输对象
 */

public class GradeDTO {
    //create table tb_grades(
    //	  snum char(10),//
    //	  cid char(5),
    //	  grade int,
    //	  primary key(snum,cid)
    //);
    private String StudentNum;
    private String CourseId;
    private int Grade;

    public String getStudentNum() {
        return StudentNum;
    }

    public void setStudentNum(String studentNum) {
        StudentNum = studentNum;
    }

    public String getCourseId() {
        return CourseId;
    }

    public void setCourseId(String courseId) {
        CourseId = courseId;
    }

    public int getGrade() {
        return Grade;
    }

    public void setGrade(int grade) {
        Grade = grade;
    }

    public GradeDTO() {
    }

    public GradeDTO(String studentNum, String courseId, int grade) {
        this.StudentNum = studentNum;
        this.CourseId = courseId;
        this.Grade = grade;
    }
}
