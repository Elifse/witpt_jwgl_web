package com.example.witpt_jwgl_web.dto;

/**
 * @author Elifse
 * @Description 用来封装管理员的信息
 * @Create 2022/4/15
 **/
public class ManagerDTO {
    private String ManagerId;
    private String ManagerPwd;
    private String ManagerName;
    private String ManagerTel;

    public String getManagerId() {
        return ManagerId;
    }

    public void setManagerId(String managerId) {
        ManagerId = managerId;
    }

    public String getManagerPwd() {
        return ManagerPwd;
    }

    public void setManagerPwd(String managerPwd) {
        ManagerPwd = managerPwd;
    }

    public String getManagerName() {
        return ManagerName;
    }

    public void setManagerName(String managerName) {
        ManagerName = managerName;
    }

    public String getManagerTel() {
        return ManagerTel;
    }

    public void setManagerTel(String managerTel) {
        ManagerTel = managerTel;
    }

    public ManagerDTO() {
    }

    public ManagerDTO(String managerId, String managerPwd, String managerName, String managerTel) {
        this.ManagerId = managerId;
        this.ManagerPwd = managerPwd;
        this.ManagerName = managerName;
        this.ManagerTel = managerTel;
    }
}
