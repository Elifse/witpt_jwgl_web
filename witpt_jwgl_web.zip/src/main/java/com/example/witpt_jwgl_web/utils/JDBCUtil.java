package com.example.witpt_jwgl_web.utils;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 * @author Elifse
 * @Description 建立数据库连接
 * @Create 2022/4/15
 **/
public class JDBCUtil {
    //创建数据库连接
    public static Connection createConnection() {
        Connection c = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://124.220.8.88:3306/db_xiaomiao_jwgl?characterEncoding=utf8";
            String user = "root";
            String password = "123456";
            c = DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return c;
    }

}
