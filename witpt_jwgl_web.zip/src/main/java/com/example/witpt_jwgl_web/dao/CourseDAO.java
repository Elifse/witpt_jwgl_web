package com.example.witpt_jwgl_web.dao;

import com.example.witpt_jwgl_web.dto.CourseDTO;
import com.example.witpt_jwgl_web.utils.JDBCUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Elifse
 * @Description 对课程表的操作
 * @Create 2022/4/16
 **/
public class CourseDAO {
    public List<CourseDTO> selectCourseByTid(String tid) {
        List<CourseDTO> list = new ArrayList<>();
        try {
            Connection connection = JDBCUtil.createConnection();
            // 编写SQL
            String sql = "select course_id,course_name,course_score,course_time,course_desc,tid from tb_courses where tid = ?";
            // 编译SQL
            PreparedStatement ps = connection.prepareStatement(sql);
            // 给SQL赋值（如果没有？占位符，则不需要赋值）
            ps.setString(1, tid);
            // 执行SQL
            ResultSet result = ps.executeQuery();
            while (result.next()) { // 判断result是否有下一行数据
                String courseId = result.getString("course_id");
                String courseName = result.getString("course_name");
                double courseScore = result.getDouble("course_score");
                int courseTime = result.getInt("course_time");
                String courseDesc = result.getString("course_desc");
                String teacherId = result.getString("tid");

                CourseDTO courseDTO = new CourseDTO(courseId, courseName, courseScore, courseTime, courseDesc, teacherId);
                // 将查询结果添加到List集合中
                list.add(courseDTO);

            }
            // 关闭链接
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    public List<CourseDTO> selectAllCourse() {

        // 新建List集合，用于存放Course对象
        List<CourseDTO> list = new ArrayList<>();

        try {
            Connection c = JDBCUtil.createConnection();
            // 编写SQL
            String sql = "select course_id,course_name,course_score,course_time,course_desc from tb_courses";
            // 编译SQL
            PreparedStatement ps = c.prepareStatement(sql);
            // 给SQL赋值（如果没有？占位符，则不需要赋值）
            // 执行SQL
            ResultSet result = ps.executeQuery();
            // 处理执行结果
            while (result.next()) { // 判断result是否有下一行数据
                String courseId = result.getString("course_id");
                String courseName = result.getString("course_name");
                double courseScore = result.getDouble("course_score");
                int courseTime = result.getInt("course_time");
                String courseDesc = result.getString("course_desc");

                CourseDTO courseDTO = new CourseDTO(courseId, courseName, courseScore, courseTime, courseDesc);
                // 将查询结果添加到List集合中
                list.add(courseDTO);

            }
            // 关闭链接
            c.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
