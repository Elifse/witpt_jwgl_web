package com.example.witpt_jwgl_web.dao;

import com.example.witpt_jwgl_web.dto.CourseDTO;
import com.example.witpt_jwgl_web.dto.StudentGrade;
import com.example.witpt_jwgl_web.utils.JDBCUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Elifse
 * @Description 对成绩表的操作
 * @Create 2022/4/16
 **/
public class GradeDAO {
    public List<StudentGrade> selectGradeByStudentId(String sid) {
        List<StudentGrade> list = new ArrayList<>();
        try {
            Connection c = JDBCUtil.createConnection();
            // 2. 创建sql语句
            String sql = "SELECT snum,stu_name,cid,course_name,course_desc,grade  FROM tb_grades INNER JOIN tb_students on tb_grades.snum = tb_students.stu_num INNER JOIN tb_courses on tb_grades.cid=tb_courses.course_id WHERE stu_num = ?;";
            // 3. 加载SQL语句
            PreparedStatement ps = c.prepareStatement(sql);
            // 4. 给SQL语句中的参数赋值
            ps.setString(1, sid);
            // 5. 执行SQL语句，同时获取执行的结果
            ResultSet result = ps.executeQuery();
            // 6.处理执行结果
            while (result.next()) {
                String studentId =  result.getString("snum");
                String studentName =  result.getString("stu_name");
                String courseId =  result.getString("cid");
                String courseName =  result.getString("course_name");
                String courseDescription =  result.getString("course_desc");
                int grade = result.getInt("grade");
                StudentGrade studentGrade = new StudentGrade(studentId, studentName, courseId, courseName, courseDescription, grade);

                list.add(studentGrade);
            }
            // 7. 关闭连接
            c.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }


    // 根据学生id和课程id查询成绩
    public boolean updateGradeByStudentId(String cid, String snum, int grade) {
        boolean flag = false;
        try {
            Connection c = JDBCUtil.createConnection();
            // 2. 创建sql语句
            String sql = "update tb_grades set grade=? where snum=? and cid=?";
            // 3. 加载SQL语句
            PreparedStatement ps = c.prepareStatement(sql);
            // 4. 给SQL语句中的参数赋值
            ps.setInt(1, grade);
            ps.setString(2, snum);
            ps.setString(3, cid);
            // 5. 执行SQL语句，同时获取执行的结果
            int result = ps.executeUpdate();
            // 6.处理执行结果
            flag = result > 0 ? true : false;
            // 7. 关闭连接
            c.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }



}
