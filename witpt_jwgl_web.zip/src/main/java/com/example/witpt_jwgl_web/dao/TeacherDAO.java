package com.example.witpt_jwgl_web.dao;


import com.example.witpt_jwgl_web.dto.TeacherDTO;
import com.example.witpt_jwgl_web.utils.JDBCUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Elifse
 * @Description 对教师表的操作
 * @Create 2022/4/15
 **/
public class TeacherDAO {
    // 1. 根据教师id和密码查询教师信息
    public TeacherDTO selectTeacherByIdAndPwd(String tid, String pwd) {
        TeacherDTO teacherDTO = null;
        try {
            Connection c = JDBCUtil.createConnection();
            String sql = "select id, login_pwd, name, gender, birthday, id_card, tel_num from tb_teachers where id = ? and login_pwd = ?";
            PreparedStatement ps = c.prepareStatement(sql);
            ps.setString(1, tid);
            ps.setString(2, pwd);
            ResultSet result = ps.executeQuery();
            while (result.next()) {
                String teacherId = result.getString("id");
                String loginPwd = result.getString("login_pwd");
                String teacherName = result.getString("name");
                String teacherGender = result.getString("gender");
                String teacherBirthday = result.getString("birthday");
                String teacherIdCard = result.getString("id_card");
                String teacherTelNum = result.getString("tel_num");
                teacherDTO = new TeacherDTO(teacherId, loginPwd, teacherName, teacherGender, teacherBirthday,
                        teacherIdCard, teacherTelNum);

            }
            c.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return teacherDTO;
    }
    // 查询所有教师信息
    public List<TeacherDTO> selectAllTeachers() {
        List<TeacherDTO> list = new ArrayList<>();
        try {
            Connection c = JDBCUtil.createConnection();
            String sql = "select id, login_pwd, name, gender, birthday, id_card, tel_num from tb_teachers";
            PreparedStatement ps = c.prepareStatement(sql);
            ResultSet result = ps.executeQuery();
            while (result.next()) {
                String teacherId = result.getString("id");
                String loginPwd = result.getString("login_pwd");
                String teacherName = result.getString("name");
                String teacherGender = result.getString("gender");
                String teacherBirthday = result.getString("birthday");
                String teacherIdCard = result.getString("id_card");
                String teacherTelNum = result.getString("tel_num");

                TeacherDTO teacherDTO = new TeacherDTO(teacherId, loginPwd, teacherName, teacherGender, teacherBirthday,
                        teacherIdCard, teacherTelNum);
                list.add(teacherDTO);
            }
            c.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
