package com.example.witpt_jwgl_web.dao;

import com.example.witpt_jwgl_web.dto.StudentDTO;
import com.example.witpt_jwgl_web.utils.JDBCUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Elifse
 * @Description 对学生表的操作
 * @Create 2022/4/15
 **/
public class StudentDAO {

    // 根据学号和密码查询学生信息
    public StudentDTO selectStudentByIdAndPwd(String sid, String pwd) {
        StudentDTO studentDTO = null;
        try {
            Connection c = JDBCUtil.createConnection();
            String sql = "select stu_num, login_pwd, stu_name, stu_gender ,stu_age ,stu_addr ,stu_img ,stu_desc from tb_students where stu_num = ? and login_pwd = ?";
            PreparedStatement ps = c.prepareStatement(sql);
            ps.setString(1, sid);
            ps.setString(2, pwd);
            ResultSet result = ps.executeQuery();
            if (result.next()) {
                String studentNum = result.getString("stu_num");
                String loginPwd = result.getString("login_pwd");
                String studentName = result.getString("stu_name");
                String studentGender = result.getString("stu_gender");
                int studentAge = result.getInt("stu_age");
                String studentAddr = result.getString("stu_addr");
                String studentImg = result.getString("stu_img");
                String studentDesc = result.getString("stu_desc");
                studentDTO = new StudentDTO(studentNum, loginPwd, studentName, studentGender, studentAge, studentAddr, studentImg, studentDesc);

            }
            c.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return studentDTO;
    }

    // 根据课程号查询学生信息
    public List<StudentDTO> selectStudentByCid(String cid) {
        List<StudentDTO> list = new ArrayList<>();
        try {
            Connection c = JDBCUtil.createConnection();
            String sql = ("select stu_num, login_pwd, stu_name, stu_gender ,stu_age ,stu_addr ,stu_img ,stu_desc from tb_students where stu_num in ( select snum from tb_grades where cid = ? )");
            PreparedStatement ps = c.prepareStatement(sql);
            ps.setString(1, cid);
            ResultSet result = ps.executeQuery();
            while (result.next()) {
                String studentNum = result.getString("stu_num");
                String loginPwd = result.getString("login_pwd");
                String studentName = result.getString("stu_name");
                String studentGender = result.getString("stu_gender");
                int studentAge = result.getInt("stu_age");
                String studentAddr = result.getString("stu_addr");
                String studentImg = result.getString("stu_img");
                String studentDesc = result.getString("stu_desc");
                StudentDTO studentDTO = new StudentDTO(studentNum, loginPwd, studentName, studentGender, studentAge, studentAddr, studentImg, studentDesc);
                list.add(studentDTO);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    // 根据学生号查询学生信息
    public StudentDTO selectStudentByNum(String sid) {
        StudentDTO studentDTO = null;
        try {
            Connection c = JDBCUtil.createConnection();
            String sql = "select stu_num, login_pwd, stu_name, stu_gender ,stu_age ,stu_addr ,stu_img ,stu_desc from tb_students where stu_num = ?";
            PreparedStatement ps = c.prepareStatement(sql);
            ps.setString(1, sid);
            ResultSet result = ps.executeQuery();
            if (result.next()) {
                String studentNum = result.getString("stu_num");
                String loginPwd = result.getString("login_pwd");
                String studentName = result.getString("stu_name");
                String studentGender = result.getString("stu_gender");
                int studentAge = result.getInt("stu_age");
                String studentAddr = result.getString("stu_addr");
                String studentImg = result.getString("stu_img");
                String studentDesc = result.getString("stu_desc");
                studentDTO = new StudentDTO(studentNum, loginPwd, studentName, studentGender, studentAge, studentAddr,
                        studentImg, studentDesc);

            }
            c.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return studentDTO;
    }

    // 查询所有学生信息
    public List<StudentDTO> selectAllStudent() {
        List<StudentDTO> list = new ArrayList<>();
        try {
            Connection c = JDBCUtil.createConnection();
            String sql = "select stu_num, login_pwd, stu_name, stu_gender ,stu_age ,stu_addr ,stu_img ,stu_desc from tb_students";
            PreparedStatement ps = c.prepareStatement(sql);
            ResultSet result = ps.executeQuery();
            while (result.next()) {
                String studentNum = result.getString("stu_num");
                String loginPwd = result.getString("login_pwd");
                String studentName = result.getString("stu_name");
                String studentGender = result.getString("stu_gender");
                int studentAge = result.getInt("stu_age");
                String studentAddr = result.getString("stu_addr");
                String studentImg = result.getString("stu_img");
                String studentDesc = result.getString("stu_desc");

                StudentDTO studentDTO = new StudentDTO(studentNum, loginPwd, studentName, studentGender, studentAge,
                        studentAddr, studentImg, studentDesc);
                list.add(studentDTO);
            }
            c.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

}
