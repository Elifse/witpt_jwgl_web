package com.example.witpt_jwgl_web.dao;

import com.example.witpt_jwgl_web.dto.ManagerDTO;
import com.example.witpt_jwgl_web.utils.JDBCUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Elifse
 * @Description 对管理员表的操作
 * @Create 2022/4/15
 **/
public class ManagerDAO {
    // 1. 根据管理员的账号和密码查询管理员信息
    public ManagerDTO selectManagerByIdAndPwd(String mid, String pwd) {
        ManagerDTO managerDTO = null;

        try {
            Connection c = JDBCUtil.createConnection();
            String sql = "select mgr_id, login_pwd, mgr_name, mgr_tel from tb_managers where mgr_id = ? and login_pwd = ?";
            PreparedStatement ps = c.prepareStatement(sql);
            ps.setString(1, mid);
            ps.setString(2, pwd);
            ResultSet result = ps.executeQuery();
            if (result.next()) {
                String mgrId = result.getString("mgr_id");
                String loginPwd = result.getString("login_pwd");
                String mgrName = result.getString("mgr_name");
                String mgrTel = result.getString("mgr_tel");
                managerDTO = new ManagerDTO(mgrId, loginPwd, mgrName, mgrTel);
            }
            c.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return managerDTO;
    }
    public List<ManagerDTO> selectAllManager() {
        List<ManagerDTO> list = new ArrayList<>();
        try {
            Connection c = JDBCUtil.createConnection();
            String sql = "select mgr_id, login_pwd, mgr_name, mgr_tel from tb_managers";
            PreparedStatement ps = c.prepareStatement(sql);
            ResultSet result = ps.executeQuery();
            while (result.next()) {
                String managerId = result.getString("mgr_id");
                String managerPwd = result.getString("login_pwd");
                String managerName = result.getString("mgr_name");
                String managerTel = result.getString("mgr_tel");
                ManagerDTO managerDTO = new ManagerDTO(managerId, managerPwd, managerName, managerTel);
                list.add(managerDTO);
            }
            c.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
